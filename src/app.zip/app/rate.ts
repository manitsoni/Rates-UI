export class Rate{
    SourceCity:string;
    SourceState:string;
    SourceCountry:string;
    DestinationCity:string;
    DestinationState:string;
    DestinationCountry:string;
    Quantity:number;
    Weight:number;
    TotalRate:number;
}